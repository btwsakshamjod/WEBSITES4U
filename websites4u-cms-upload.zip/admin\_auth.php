<?php
require_once __DIR__ . '/../config/db.php';

function admin_header(string $title): void
{
    require_admin();
    $nav = [
        'index.php' => 'Settings',
        'manage.php?type=industries' => 'Industries',
        'manage.php?type=stats' => 'Stats',
        'manage.php?type=services' => 'Services',
        'manage.php?type=why_cards' => 'Why Cards',
        'manage.php?type=projects' => 'Projects',
        'manage.php?type=features' => 'Features',
        'manage.php?type=pricing_plans' => 'Pricing',
        'manage.php?type=testimonials' => 'Testimonials',
        'leads.php' => 'Leads',
    ];
    ?>
    <!doctype html>
    <html lang="en">
    <head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <title><?= e($title) ?> - Admin</title>
      <script src="https://cdn.tailwindcss.com"></script>
    </head>
    <body class="bg-slate-100 font-sans text-slate-950">
      <div class="min-h-screen md:flex">
        <aside class="bg-slate-950 p-5 text-white md:w-72">
          <div class="text-2xl font-black">Websites4U Admin</div>
          <nav class="mt-6 grid gap-2 text-sm font-bold">
            <?php foreach ($nav as $href => $label): ?>
              <a class="rounded-xl px-4 py-3 hover:bg-white/10" href="<?= e($href) ?>"><?= e($label) ?></a>
            <?php endforeach; ?>
          </nav>
          <div class="mt-8 grid gap-2 text-sm">
            <a class="rounded-xl bg-blue-600 px-4 py-3 text-center font-black" href="../index.php" target="_blank">View Website</a>
            <a class="rounded-xl bg-white/10 px-4 py-3 text-center font-black" href="logout.php">Logout</a>
          </div>
        </aside>
        <main class="flex-1 p-5 md:p-8">
          <h1 class="text-3xl font-black"><?= e($title) ?></h1>
    <?php
}

function admin_footer(): void
{
    echo '</main></div></body></html>';
}

function flash(): ?string
{
    $message = $_SESSION['flash'] ?? null;
    unset($_SESSION['flash']);
    return $message;
}

function set_flash(string $message): void
{
    $_SESSION['flash'] = $message;
}
