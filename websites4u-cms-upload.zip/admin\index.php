<?php
require_once __DIR__ . '/_auth.php';

$editable = [
    'site_name', 'meta_title', 'meta_description', 'phone_number', 'whatsapp_number',
    'email', 'instagram_url', 'hero_badge', 'hero_title', 'hero_description',
    'hero_primary_button', 'hero_secondary_button', 'services_heading', 'services_subtitle',
    'about_heading', 'about_text', 'projects_heading', 'projects_text',
    'pricing_heading', 'pricing_text', 'testimonials_heading', 'contact_heading',
    'contact_text', 'footer_text', 'whatsapp_message'
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    foreach ($editable as $key) {
        $stmt = db()->prepare('INSERT INTO settings (setting_key, setting_value) VALUES (?, ?) ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)');
        $stmt->execute([$key, $_POST[$key] ?? '']);
    }
    set_flash('Settings saved.');
    header('Location: index.php');
    exit;
}

admin_header('Website Settings');
$message = flash();
?>
<?php if ($message): ?><div class="mt-5 rounded-xl bg-emerald-50 p-4 font-bold text-emerald-700"><?= e($message) ?></div><?php endif; ?>
<form method="post" class="mt-6 grid gap-5 rounded-2xl bg-white p-6 shadow-lg">
  <div class="grid gap-5 md:grid-cols-2">
    <?php foreach ($editable as $key): ?>
      <?php $long = str_contains($key, 'text') || str_contains($key, 'description') || str_contains($key, 'message'); ?>
      <label class="grid gap-2 font-bold <?= $long ? 'md:col-span-2' : '' ?>">
        <?= e(ucwords(str_replace('_', ' ', $key))) ?>
        <?php if ($long): ?>
          <textarea class="min-h-28 rounded-xl border border-slate-200 p-3 font-normal" name="<?= e($key) ?>"><?= e(setting($key)) ?></textarea>
        <?php else: ?>
          <input class="rounded-xl border border-slate-200 p-3 font-normal" name="<?= e($key) ?>" value="<?= e(setting($key)) ?>">
        <?php endif; ?>
      </label>
    <?php endforeach; ?>
  </div>
  <button class="w-fit rounded-full bg-blue-600 px-6 py-3 font-black text-white">Save Settings</button>
</form>
<?php admin_footer(); ?>
