<?php
require_once __DIR__ . '/_auth.php';

if (isset($_GET['delete'])) {
    $stmt = db()->prepare('DELETE FROM leads WHERE id = ?');
    $stmt->execute([(int) $_GET['delete']]);
    set_flash('Lead deleted.');
    header('Location: leads.php');
    exit;
}

$leads = db()->query('SELECT * FROM leads ORDER BY created_at DESC')->fetchAll();
admin_header('Leads');
$message = flash();
?>
<?php if ($message): ?><div class="mt-5 rounded-xl bg-emerald-50 p-4 font-bold text-emerald-700"><?= e($message) ?></div><?php endif; ?>
<div class="mt-6 overflow-x-auto rounded-2xl bg-white p-6 shadow-lg">
  <table class="w-full min-w-[900px] text-left text-sm">
    <thead><tr class="border-b text-slate-500"><th class="py-3">Date</th><th>Name</th><th>Phone</th><th>Business</th><th>Message</th><th class="text-right">Action</th></tr></thead>
    <tbody>
      <?php foreach ($leads as $lead): ?>
        <tr class="border-b last:border-0">
          <td class="py-3"><?= e($lead['created_at']) ?></td>
          <td class="font-bold"><?= e($lead['name']) ?></td>
          <td><a class="font-bold text-blue-600" href="tel:<?= e($lead['phone']) ?>"><?= e($lead['phone']) ?></a></td>
          <td><?= e($lead['business_type']) ?></td>
          <td><?= e($lead['message']) ?></td>
          <td class="text-right"><a class="font-black text-red-600" onclick="return confirm('Delete this lead?')" href="leads.php?delete=<?= e((string)$lead['id']) ?>">Delete</a></td>
        </tr>
      <?php endforeach; ?>
      <?php if (!$leads): ?><tr><td colspan="6" class="py-8 text-center text-slate-500">No leads yet.</td></tr><?php endif; ?>
    </tbody>
  </table>
</div>
<?php admin_footer(); ?>
